Core/Src/main.o: ../Core/Src/main.c \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Core/Inc/main.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Core/Inc/stm32l0xx_hal_conf.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_rcc.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_def.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/CMSIS/Device/ST/STM32L0xx/Include/stm32l0xx.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/CMSIS/Device/ST/STM32L0xx/Include/stm32l071xx.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/CMSIS/Include/core_cm0plus.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/CMSIS/Include/cmsis_version.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/CMSIS/Include/cmsis_compiler.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/CMSIS/Include/cmsis_gcc.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/CMSIS/Include/mpu_armv7.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/CMSIS/Device/ST/STM32L0xx/Include/system_stm32l0xx.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_rcc_ex.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_exti.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_gpio.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_gpio_ex.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_dma.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_cortex.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_adc.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_adc_ex.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_flash.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_flash_ex.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_flash_ramfunc.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_i2c.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_i2c_ex.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_iwdg.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_pwr.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_pwr_ex.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_rtc.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_rtc_ex.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_tim.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_tim_ex.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_uart.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_uart_ex.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS/cmsis_os.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Middlewares/Third_Party/FreeRTOS/Source/include/FreeRTOS.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Core/Inc/FreeRTOSConfig.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Middlewares/Third_Party/FreeRTOS/Source/include/projdefs.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Middlewares/Third_Party/FreeRTOS/Source/include/portable.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Middlewares/Third_Party/FreeRTOS/Source/include/deprecated_definitions.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM0/portmacro.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Middlewares/Third_Party/FreeRTOS/Source/include/mpu_wrappers.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Middlewares/Third_Party/FreeRTOS/Source/include/task.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Middlewares/Third_Party/FreeRTOS/Source/include/list.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Middlewares/Third_Party/FreeRTOS/Source/include/timers.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Middlewares/Third_Party/FreeRTOS/Source/include/task.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Middlewares/Third_Party/FreeRTOS/Source/include/queue.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Middlewares/Third_Party/FreeRTOS/Source/include/semphr.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Middlewares/Third_Party/FreeRTOS/Source/include/queue.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Middlewares/Third_Party/FreeRTOS/Source/include/event_groups.h \
 D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Middlewares/Third_Party/FreeRTOS/Source/include/timers.h

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Core/Inc/main.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Core/Inc/stm32l0xx_hal_conf.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_rcc.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_def.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/CMSIS/Device/ST/STM32L0xx/Include/stm32l0xx.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/CMSIS/Device/ST/STM32L0xx/Include/stm32l071xx.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/CMSIS/Include/core_cm0plus.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/CMSIS/Include/cmsis_version.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/CMSIS/Include/cmsis_compiler.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/CMSIS/Include/cmsis_gcc.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/CMSIS/Include/mpu_armv7.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/CMSIS/Device/ST/STM32L0xx/Include/system_stm32l0xx.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_rcc_ex.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_exti.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_gpio.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_gpio_ex.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_dma.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_cortex.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_adc.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_adc_ex.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_flash.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_flash_ex.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_flash_ramfunc.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_i2c.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_i2c_ex.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_iwdg.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_pwr.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_pwr_ex.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_rtc.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_rtc_ex.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_tim.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_tim_ex.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_uart.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_uart_ex.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS/cmsis_os.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Middlewares/Third_Party/FreeRTOS/Source/include/FreeRTOS.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Core/Inc/FreeRTOSConfig.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Middlewares/Third_Party/FreeRTOS/Source/include/projdefs.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Middlewares/Third_Party/FreeRTOS/Source/include/portable.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Middlewares/Third_Party/FreeRTOS/Source/include/deprecated_definitions.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM0/portmacro.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Middlewares/Third_Party/FreeRTOS/Source/include/mpu_wrappers.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Middlewares/Third_Party/FreeRTOS/Source/include/task.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Middlewares/Third_Party/FreeRTOS/Source/include/list.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Middlewares/Third_Party/FreeRTOS/Source/include/timers.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Middlewares/Third_Party/FreeRTOS/Source/include/task.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Middlewares/Third_Party/FreeRTOS/Source/include/queue.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Middlewares/Third_Party/FreeRTOS/Source/include/semphr.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Middlewares/Third_Party/FreeRTOS/Source/include/queue.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Middlewares/Third_Party/FreeRTOS/Source/include/event_groups.h:

D:/���ؿ�/02_softwave/2025_magnetic\ Sensor/02_DRM_Controller_v1.0_magnetic_Master/Middlewares/Third_Party/FreeRTOS/Source/include/timers.h:
